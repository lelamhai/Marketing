<div class="footerContainer">
                  <footer class="footerContent">
                     <div class="footerInner">
                        <div class="wrap-footer-top">
                           <div class="footer-left">
                              <div class="blockContainer h-blockContainer-footer blockWrap_dfcda1b6f0614f3ea2ef32dfff9f0ae2 ">
                                 <div class="blockContent block_dfcda1b6f0614f3ea2ef32dfff9f0ae2  ">
                                    <div class="blockInnerContent">
                                       <div class="blockImg footerLogo"><a href="#"><img src="<?php echo get_bloginfo("template_directory"); ?>/assets/imgs/logoWhite.png" alt="" class="contentImg"></a></div>
                                    </div>
                                 </div>
                                 <!-- /blockContent -->
                                 <div class="blockContent block_cb69f2836c1e4fd3ae3c58325e352bf6  trustLogos">
                                    <div class="blockInnerContent">
                                       <ul>
                                          <li><a href=""><img src="<?php echo get_bloginfo("template_directory"); ?>/assets/imgs/badgeinc5000-100.png" alt="Inc 5000 Fastest Growing" class="contentImg"></a></li>
                                          <li><a href=""><img src="<?php echo get_bloginfo("template_directory"); ?>/assets/imgs/badgeglassdoor-100.png" alt="Glassdoor Best Places to Work" class="contentImg"></a></li>
                                          <li><a href=""><img src="<?php echo get_bloginfo("template_directory"); ?>/assets/imgs/badgefamily-100.png" alt="Top 50 Family Owned Colorado Biz" class="contentImg"></a></li>
                                          <li><a href="https://www.marketing360.com/military-discount"><img src="<?php echo get_bloginfo("template_directory"); ?>/assets/imgs/militaryDiscount230.png" alt="Military Discount" class="contentImg"></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="footer-right">
                              <!-- /blockContainer -->
                              <div class="blockContainer h-right-footer">
                                 <div class="blockContent block_c637705c1911407589c1e6085d62c077 ">
                                    <div class="blockText">
                                       <h2 class="contentTitle">More</h2>
                                       <div class="blockInnerContent">
                                          <ul class="unstyledList">
                                             <li><a href="https://www.marketing360.com/about">About Us</a></li>
                                             <li><a href="https://www.marketing360.com/creative-services">Creative Services</a></li>
                                             <li><a href="https://www.marketing360.com/success-stories">Success Stories</a></li>
                                             <li><a href="https://www.marketing360.com/our-reviews">Our Reviews</a></li>
                                             <li><a href="https://partners.marketing360.com/">Partner With Us</a></li>
                                             <li><a href="https://marketplace.marketing360.com/">Marketplace</a></li>
                                             <li><a href="https://blog.marketing360.com/">Blog</a></li>
                                             <li><a href="https://podcast.madwire.com/" target="_blank" rel="noopener noreferrer">Podcast</a></li>
                                             <li><a href="https://pages.marketing360.com/community-offers">Community Offers</a></li>
                                             <li><a href="https://integrations.marketing360.com/">Integrations</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                    <!-- /blockText-->
                                 </div>
                                 <!-- /blockContent -->
                              </div>
                              <!-- /blockContainer -->
                              <div class="blockContainer h-right-footer">
                                 <div class="blockContent block_c637705c1911407589c1e6085d62c077 ">
                                    <div class="blockText">
                                       <h2 class="contentTitle">More</h2>
                                       <div class="blockInnerContent">
                                          <ul class="unstyledList">
                                             <li><a href="https://www.marketing360.com/about">About Us</a></li>
                                             <li><a href="https://www.marketing360.com/creative-services">Creative Services</a></li>
                                             <li><a href="https://www.marketing360.com/success-stories">Success Stories</a></li>
                                             <li><a href="https://www.marketing360.com/our-reviews">Our Reviews</a></li>
                                             <li><a href="https://partners.marketing360.com/">Partner With Us</a></li>
                                             <li><a href="https://marketplace.marketing360.com/">Marketplace</a></li>
                                             <li><a href="https://blog.marketing360.com/">Blog</a></li>
                                             <li><a href="https://podcast.madwire.com/" target="_blank" rel="noopener noreferrer">Podcast</a></li>
                                             <li><a href="https://pages.marketing360.com/community-offers">Community Offers</a></li>
                                             <li><a href="https://integrations.marketing360.com/">Integrations</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                    <!-- /blockText-->
                                 </div>
                                 <!-- /blockContent -->
                              </div>
                              <!-- /blockContainer -->
                              <div class="blockContainer h-right-footer">
                                 <div class="blockContent block_c637705c1911407589c1e6085d62c077 ">
                                    <div class="blockText">
                                       <h2 class="contentTitle">More</h2>
                                       <div class="blockInnerContent">
                                          <ul class="unstyledList">
                                             <li><a href="https://www.marketing360.com/about">About Us</a></li>
                                             <li><a href="https://www.marketing360.com/creative-services">Creative Services</a></li>
                                             <li><a href="https://www.marketing360.com/success-stories">Success Stories</a></li>
                                             <li><a href="https://www.marketing360.com/our-reviews">Our Reviews</a></li>
                                             <li><a href="https://partners.marketing360.com/">Partner With Us</a></li>
                                             <li><a href="https://marketplace.marketing360.com/">Marketplace</a></li>
                                             <li><a href="https://blog.marketing360.com/">Blog</a></li>
                                             <li><a href="https://podcast.madwire.com/" target="_blank" rel="noopener noreferrer">Podcast</a></li>
                                             <li><a href="https://pages.marketing360.com/community-offers">Community Offers</a></li>
                                             <li><a href="https://integrations.marketing360.com/">Integrations</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                    <!-- /blockText-->
                                 </div>
                                 <!-- /blockContent -->
                              </div>
                              <!-- /blockContainer -->
                              <div class="blockContainer h-right-footer">
                                 <div class="blockContent block_c637705c1911407589c1e6085d62c077 ">
                                    <div class="blockText">
                                       <h2 class="contentTitle">More</h2>
                                       <div class="blockInnerContent">
                                          <ul class="unstyledList">
                                             <li><a href="https://www.marketing360.com/about">About Us</a></li>
                                             <li><a href="https://www.marketing360.com/creative-services">Creative Services</a></li>
                                             <li><a href="https://www.marketing360.com/success-stories">Success Stories</a></li>
                                             <li><a href="https://www.marketing360.com/our-reviews">Our Reviews</a></li>
                                             <li><a href="https://partners.marketing360.com/">Partner With Us</a></li>
                                             <li><a href="https://marketplace.marketing360.com/">Marketplace</a></li>
                                             <li><a href="https://blog.marketing360.com/">Blog</a></li>
                                             <li><a href="https://podcast.madwire.com/" target="_blank" rel="noopener noreferrer">Podcast</a></li>
                                             <li><a href="https://pages.marketing360.com/community-offers">Community Offers</a></li>
                                             <li><a href="https://integrations.marketing360.com/">Integrations</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                    <!-- /blockText-->
                                 </div>
                                 <!-- /blockContent -->
                              </div>
                           </div>
                        </div>
                        <!-- /blockContainer -->
                        <div class="blockContainer blockWrap_d2614212e52249088bf7d7438a2cf87e ">
                           <div class="blockContent block_d2614212e52249088bf7d7438a2cf87e ">
                              <h2 class="contentTitle dividerTitle  dividerTitle--noText"><span class="dividerTitle-textWrap"></span></h2>
                           </div>
                           <!-- /blockContent -->
                        </div>
                        <!-- /blockContainer -->
                        <div class="blockContainer socialIconsContainer blockWrap_cdfe7cb580ea4baa9e91eac4c05c9357 ">
                           <div class="blockContent block_cdfe7cb580ea4baa9e91eac4c05c9357 txa0">
                              <ul class="iconGroup socialIcons footerSocialIcons">
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/marketing360/" class="zocial facebook" aria-label="facebook"></a></li>
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/channel/UC2kyfjZNXSPLwUyPYaYPsdg?sub_confirmation=1" class="zocial youtube" aria-label="youtube"></a></li>
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://twitter.com/marketing360?lang=en" class="zocial twitter" aria-label="twitter"></a></li>
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://www.instagram.com/marketing360/?hl=en" class="zocial instagram" aria-label="instagram"></a></li>
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://www.pinterest.com/marketing360/" class="zocial pinterest" aria-label="pinterest"></a></li>
                                 <li><a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/company/marketing-360%C2%AE/" class="zocial linkedin" aria-label="linkedin"></a></li>
                              </ul>
                           </div>
                           <!-- /blockContent -->
                        </div>
                        <!-- /blockContainer -->
                        <div class="blockContainer blockWrap_eebc447109b1486f83676d4bdd19b158 ">
                           <div class="blockContent block_eebc447109b1486f83676d4bdd19b158 ">
                              <div class="blockText">
                                 <div class="blockInnerContent">
                                    <ul class="unstyledList">
                                       <li><a href="https://www.marketing360.com/branding-guidelines">Brand Guidelines</a></li>
                                       <li><a href="https://www.marketing360.com/terms">Legal</a></li>
                                       <li><a href="https://www.marketing360.com/privacy-policy">Privacy Policy</a></li>
                                       <li><a href="https://www.marketing360.com/do-not-sell">Do Not Sell My Info</a></li>
                                       <li><a href="https://www.marketing360.com/privacy-policy-california-residents">Your California Privacy Rights</a></li>
                                       <li><a href="https://www.ftc.gov/news-events/press-releases/2013/03/ftc-staff-revises-online-advertising-disclosure-guidelines">Affiliate Links Disclosures </a></li>
                                    </ul>
                                 </div>
                              </div>
                              <!-- /blockText-->
                           </div>
                           <!-- /blockContent -->
                        </div>
                        <!-- /blockContainer -->
                        <div class="blockContainer blockWrap_fa057ddf9b664c9eb3b18792662343c1" style="padding-top: 30px;">
                           <div class="blockContent block_fa057ddf9b664c9eb3b18792662343c1  paymentDisclaimer">
                              <div class="blockInnerContent">
                                 <p>Madwire LLC is a registered ISO of Wells Fargo Bank, N.A., Concord, CA.</p>
                              </div>
                           </div>
                           <!-- /blockContent -->
                        </div>
                        <!-- /blockContainer -->
                        <div class="blockContainer blockWrap_cb69f2836c1e4fd3ae3c58325e352bf6 " style="display: none;">
                           <!-- /blockContent -->
                        </div>
                        <!-- /blockContainer -->
                        <!-- /blockContainer -->
                        <div class="scCredit"><a href="https://www.websites360.com/" target="_blank" rel="nofollow">Created with <span>Websites 360</span></a></div>
                     </div>
                  </footer>
               </div>
               <!--  /footerContainer -->
            </div>
            <!-- /pageContainer -->
         </div>
         <!-- /siteInnerWrapper -->
      </div>
      <?php wp_footer(); ?>
      <script src="//code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="<?php echo get_bloginfo("template_directory"); ?>/assets/js/animation.js?v=4"></script>
      <script src="<?php echo get_bloginfo("template_directory"); ?>/assets/js/main.js?v=1"></script>
      <script>
         var TxtType = function(el, toRotate, period) {
                 this.toRotate = toRotate;
                 this.el = el;
                 this.loopNum = 0;
                 this.period = parseInt(period, 10) || 2000;
                 this.txt = '';
                 this.tick();
                 this.isDeleting = false;
             };
             TxtType.prototype.tick = function() {
                 var i = this.loopNum % this.toRotate.length;
                 var fullTxt = this.toRotate[i];
                 if (this.isDeleting) {
                 this.txt = fullTxt.substring(0, this.txt.length - 1);
                 } else {
                 this.txt = fullTxt.substring(0, this.txt.length + 1);
                 }
                 this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';
                 var that = this;
                 var delta = 200 - Math.random() * 100;
                 if (this.isDeleting) { delta /= 2; }
                 if (!this.isDeleting && this.txt === fullTxt) {
                 delta = this.period;
                 this.isDeleting = true;
                 } else if (this.isDeleting && this.txt === '') {
                 this.isDeleting = false;
                 this.loopNum++;
                 delta = 900;
                 }
                 setTimeout(function() {
                     that.tick();
                 }, delta);
             };
             window.onload = function() {
                 var elements = document.getElementsByClassName('typewrite');
                 for (var i=0; i<elements.length; i++) {
                     var toRotate = elements[i].getAttribute('data-type');
                     var period = elements[i].getAttribute('data-period');
                     if (toRotate) {
                       new TxtType(elements[i], JSON.parse(toRotate), period);
                     }
                 }
                 // INJECT CSS
                 var css = document.createElement("style");
                 css.type = "text/css";
                 css.innerHTML = ".typewrite > .wrap { border-right: 2px solid #325e89}";
                 document.body.appendChild(css);
             };
      </script>
   </body>
</html>